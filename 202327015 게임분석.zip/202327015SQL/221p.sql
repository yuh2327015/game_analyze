SELECT NAME
		,IFNULL(indepyear,'없음') AS '독립연도'
FROM country;