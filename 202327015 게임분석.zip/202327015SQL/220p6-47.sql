SELECT ranks
		,movie_name
		,case when QUARTER(release_date) IN(1,2) then '상반기'
			ELSE '하반기'
			END case1
FROM box_office
WHERE YEAR(release_date) = 2019 AND ranks <= 10
ORDER BY 1;